use std::io;
use std::io::stdin;

// Function to calculate both quiz marks
fn return_quiz(i: f32, j: f32) -> f32 {
let sum =(i + j)/200.0 ;
 sum*30.0
  }

// Function to calculate assignment 1 marks  
fn return_a1(a: f32) -> f32 {
    let sum =a/ 200.0;
    sum*25.0    
}

// Function to calculate assignment 2 marks 
fn return_a2(c: f32) -> f32 {
    let sum =c/ 100.0;
    sum*25.0
    
}

// Function to calculate assignment 3 marks 
fn return_a3(e: f32) -> f32 {
    let sum =e/ 50.0;
    sum*20.0
    
}
  
fn main() {
    println!("Welcome to Grade Calculator");
    println!("---------");
    println!("Enter your Name:");
    println!("Enter your quiz 1 marks");
    println!("Enter your quiz 2 marks");
    println!("Enter your Assignment 1 marks");
    println!("Enter your Assignment 2 marks");
    println!("Enter your Assignment 3 marks");

    // Created loop so it continues the program, even after showing the grade (it will not break)
    loop {
        println!("Enter your Name: ");
        let mut name = String::new();
        // This will appear if it will unable to read the line (user input)
        stdin().read_line(&mut name).ok().expect("Failed to read line");
        
        println!("Enter your quiz 1 marks in range of 1-100: ");
        let mut quiz1 = String::new();
        io::stdin().read_line(&mut quiz1).expect("Failed to read line");
        // It will only take numbers as an input
        let q1:f32 = quiz1.trim().parse().ok().expect("Program only processes numbers, Enter number");

        println!("Enter your quiz 2 marks in range of 1-100: ");
        let mut quiz2 = String::new();
        io::stdin().read_line(&mut quiz2).expect("Failed to read line");
        let q2:f32 = quiz2.trim().parse().ok().expect("Program only processes numbers, Enter number");

        println!("Enter your assignment 1 marks in range of 1-200");
        let mut topping = String::new();
        io::stdin().read_line(&mut topping).expect("Failed to read line");
        let  a1: f32 = topping.trim().parse().ok().expect("Program only processes numbers, Enter number");

        println!("Enter your assignment 2 marks in range of 1-100");
        let mut assi2 = String::new();
        io::stdin().read_line(&mut assi2).expect("Failed to read line");
        let  a2: f32 = assi2.trim().parse().ok().expect("Program only processes numbers, Enter number");

        println!("Enter your assignment 3 marks in range of 1-50");
        let mut assi3 = String::new();
        io::stdin().read_line(&mut assi3).expect("Failed to read line");
        let  a3: f32 = assi3.trim().parse().ok().expect("Program only processes numbers, Enter number");

        if (q1>=0.0 && q1<=100.0) && (q2>=0.0 && q2<= 100.0) && (a1>=0.0 && a1<= 200.0) && (a2>=0.0 && a2<= 100.0) && (a3>=0.0 && a3<= 50.0)  {
            let  quiz: f32= return_quiz(q1,q2);
            let assignment1: f32  = return_a1(a1);
            let assignment2: f32  = return_a2(a2);
            let assignment3: f32  = return_a3(a3);
            let total: f32 =  quiz+assignment1+assignment2+assignment3;
            println!("Total {}", total);

            //Displaying the final result
            if total>= 93.0 && total <=100.0{ 
                println!("Your Name is {}, and your scores are: {} and Your Grade is A",name, total );
            } else if total>= 85.0 && total <=92.99{
                println!("Your Name is {}, and your scores are: {} and Your Grade is B",name, total );
            } else if total>= 75.0 && total <=84.99{
                println!("Your Name is {}, and your scores are: {} and Your Grade is C",name, total );
            } else if total>= 65.0 && total <=74.99{     
                println!("Your Name is {}, and your scores are: {} and Your Grade is D",name, total );
            } else if total>= 60.0 && total <=64.99{     
                println!("Your Name is {}, and your scores are: {} and Your Grade is E",name, total );
            } else if  total<60.0{     
                println!("Your Name is {}, and your scores are: {} and Your Grade is F",name, total );
            } 
        }
        else{
            // It will show if the number is not in range.
            println!("---------------Error!!!!!!!!!!!!!!!!-------------");
            println!("Please Enter number in range.");
        }
    }
}
