// This file will run modules function
// Uncomment expected modules to make it run

// mod prints;
// mod types;
// mod vars;
// mod strings;
// mod conditionals;
// mod loops;
mod functions;

fn main() {
    // prints::run();
    // types::run();
    // vars::run();
    // strings::run();
    // conditionals::run();
    // loops::run();
    functions::run();
}
